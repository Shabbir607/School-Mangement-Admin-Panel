@extends('ApproveForm.app')
@section('title')
    settingLanguage
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }
    .container {
            max-width: 500px;
        }
        dl, ol, ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

</style>
@section('content')
<div class="container mt-5">
    <form action="{{route('saveSetting_Language')}}" method="post" enctype="multipart/form-data">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            
           
            <input type="text" name="thi" class="custom-name_th" id="name_th">
            <label class="custom-name_th" for="name_th">Thai Language</label>
            <input type="text" name="english" class="custom-name_en" id="name_en">
            <label class="custom-name_en" for="EngName">English Language</label>
            <input type="text" name="keyword" class="custom-name_en" id="keyword">
            <label class="custom-keyword" for="keyword">keyword</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>
<table id="setLang">
    <thead>
    <tr>
        <th>ID</th>
        <th>Thai Language</th>
        <th>English</th>
        <th>Keyword</th>
        <th>status</th>
        <th>Actions</th>

    </tr>
    </thead>
    <tbody>

@foreach ($sLanguage as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        
        <td>{{$user->thi}}</td>
        <td>{{$user->english}}</td>
        <td>{{$user->keyword}}</td>
        <td>{{$user->status}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
