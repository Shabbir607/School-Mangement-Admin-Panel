@extends('ApproveForm.app')
@section('title')
    SchoolDocument
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>

<table id="SchoolDocument">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>School lnc</th>
        <th>School lnc Expire</th>
        
        
       

    </tr>
    </thead>
    <tbody>
@foreach ($schooldocument as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->name}}</td>
        <td>{{$user->school}}</td>
        <td>{{$user->school_end}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

