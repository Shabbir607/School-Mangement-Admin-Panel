<style>
   .main-sidebar{
    background-color: black;
   }
   .brand-text{
    color:  #ffc205;
    font-weight: bold;
    font-family: arial;
    letter-spacing: 1px;
   }
   .user-panel{
    display: flex;
    align-items: center;
    margin: 10px 0 15px 0;
    padding: 10px 15px;
   }
   .user-panel img{
    border-radius: 50%;
    margin-right: 10px
   }
   .mt-2 span{
    color: #ffc205;
   }

</style>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="{{asset('dashboard-assets/dist/img/AdminLTELogo.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3">
      <span class="brand-text font-weight-light">Logo Name</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
           
             <img src="{{$profile_picture}}" alt="User Image">
             <a href="#" class="">{{$name}}</a>
           
        </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

               <!-- Home  -->

               <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Home
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href= "{{ route('home_present')}}" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Present Form</span>
                            
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_leave')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Leave Form</span>
                            
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_request_form')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Request Form</span>
                            
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_Stationary')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Statinary Form</span>
                            
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_Purchase')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Purchase Form</span>
                            
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_booking')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Booking Form</span>
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('home_cctv')}}" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>CCTV Form</span>
                            
                            </p>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Setting -->
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Setting
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('setting_Language')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Language</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('setting_stationary')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Stationary</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('setting_book')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Room Booking</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('setting_cctv')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>CCTV</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
             

             <!-- Employee -->
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Employee
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('schoollater')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>School Letter</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('notification')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Notification</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('group')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Group</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('schoolinfo')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>School Information</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('payroll')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Payroll</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('leavetype')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Leave Type</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('workingTime')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Working Time</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('employeeList')}}" 
                                class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Employee List</p>
                                </a>
                            </li>
            
                            <li class="nav-item">
                                <a href="{{ route('leavetype')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Leave Type</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('nationality')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Nationality</p>
                                </a>
                            </li>
                        
                            <li class="nav-item">
                                <a href="{{ route('education')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Education</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('attendance')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Attendence</p>
                                </a>
                            </li>
                        
                            <li class="nav-item">
                                <a href="{{ route('homeroom')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>HoomRoom</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('document')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Document</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Document</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            
                            <li class="nav-item">
                                <a href="{{ route('visadocument')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Visa</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('workdocument')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Work Permit</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('contract')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Contract</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('teachingdocument')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Teaching License</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('schooldocument')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>School Document</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>


            <!-- My Website -->

            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    My Website
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('myWeb_menu')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Website Menu</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('myWeb_info')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Website Information</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('myWeb_contect')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Website</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>


            <!-- Student -->
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Student
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('studentLevel')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Level</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('studentclassroom')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Class Room</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('stuinfocurrent')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Current Student</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('stuinfoalumni')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Alumni</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>

             <!-- Stationary -->
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Stationary
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('sbrand')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Brand</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('scategory')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Category</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('sunit')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Unit</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('sitem')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Product List</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('simport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Import Products</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('ssale')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Sale</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('sapprove')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Approve</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('sbillimport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>In The Completion of The Import</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('sbroken')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Defective Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('srefund')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Return</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Report</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('ssalereport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Disbursement Report</p>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="{{ route('simportreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Product Import Report</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('sbrokenreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Report a Defective Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('summaryreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Inventory Report</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>

            <!-- Academic -->
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Academic
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('ac_Subject')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Subject</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('ac_Level')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Level</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('ac_ClassRoom')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Class Room</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('ac_InfoAfter')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>After School</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('ac_InfoIntrov')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Intervention</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('homeclassroom')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Homeroom Teacher</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Report</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('ac_Rep_After')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>After School</p>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="{{ route('ac_Rep_Introv')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Intervention</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            

            <!-- Product Form -->

            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                    Product
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="#" class="nav-link" class="col-1">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Setting</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('probrand')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Brand</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('prounit')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Unit</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('procategory')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Category</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Information</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('proitem')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('proimport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Import</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('prosale')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Sale</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('proapprove')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Approve</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('probillimport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>In The Completion of The Import</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('probroken')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Broken</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('prorefund')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>CN Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('proecommerce')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Ecommerce</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                   

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Report</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('prosalereport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Disbursement Report</p>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="{{ route('proimportreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Product Import Report</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('probrokenreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Report a Defective Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('summaryreport')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Inventory Report</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>

             <!-- Approve Form Sidebar -->

            <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-circle"></i>
                    <p>
                        Approve Form
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview main">
                    <li class="nav-item child">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Waiting List</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview sub">
                            <li class="nav-item">
                                <a href="{{ route('present_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Present Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('leave_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Leave Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('request_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Request Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('stationary_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Stationary Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('purchase_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Purchase Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('booking_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Booking Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('cctv_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>CCTV Form</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item child">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Approved</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview sub">
                            <li class="nav-item">
                                <a href="{{ route('approve_present_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Present Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_leave_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Leave Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_request_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Request Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_stationary_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Stationary Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_purchase_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Purchase Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_booking_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Booking Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('approve_cctv_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>CCTV Form</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item child">
                        <a href="#" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>
                            <span>Rejected</span>
                            <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview sub">
                           <li class="nav-item">
                                <a href="{{ route('rej_present_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Present Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_leave_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Leave Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_request_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Request Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_stationary_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Stationary Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_purchase_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Purchase Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_booking_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>Booking Form</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('rej_cctv_form')}}" class="nav-link">
                                    <i class="far fa-dot-circle nav-icon"></i>
                                    <p>CCTV Form</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
           
        
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
    
</aside>
