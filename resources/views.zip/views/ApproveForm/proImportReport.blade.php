@extends('ApproveForm.app')
@section('title')
    proImportReportS
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')


<table id="proImport">
  <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Code</th>
        <th>Qty</th>
        <th>Price/Unit</th>
        <th>Supplier Name</th>
        <th>Invoice</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
@foreach ($proImportReport as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->code}}</td>
        <td>{{$user->qty}}</td>
        <td>{{$user->price}}</td>
        <td>{{$user->supplier}}</td>
        <td>{{$user->invoice}}</td>
         
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
