@extends('ApproveForm.app')
@section('title')
    homeCctv
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>


<div class="container mt-5">
    <form action="{{route('savehome_cctv')}}" method="post" enctype="multipart/form-data">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
          <label class="custom-file-label" for="chooseFile">Select file</label>
            <input type="file" name="file" class="custom-file-input" id="chooseFile">
            <label class="custom-dvr" for="dvr">DVR Number</label>
            <select name="dvr" id="dvr">
                  <option >DVR 1</option>
                  <option >DVR 2</option>
                  <option >DVR 3</option>
                  <option >DVR 4</option>
                  <option >DVR 5</option>
                  <option >DVR 6</option>
                  <option >DVR 7</option>
                  <option >DVR 8</option>
                  <option >DVR 9</option>
            </select>
             
            <label class="custom-category" for="channel">Channel</label>
            <select name="channel" id="category">
                  <option >1</option>
                  <option >2</option>
                  <option >3</option>
                  <option >4</option>
                  <option >5</option>
                  <option >6</option>
                  <option >7</option>
                  <option >8</option>
                  <option >9</option>
            </select>

            <label class="custom-date" for="channel">Date</label>
             <input type="date" name="date" class="date" id="date">
             <label class="custom-time" for="time">Time</label>
             <input type="time" name="time" class="time" id="time">
             <label class="custom-note" for="note">Note</label>
             <input type="text" name="note" class="note" id="note">
             
        </div>
        
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>
<table id="homeCctv">
    <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Time</th>
        <th>Picture</th>
        <th>DVR Name</th>
        <th>Channel</th>
        <th>Description</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
@foreach ($homeCctv as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->time}}</td>
        <td><img src="{{base_path().'/public/file/'.$user->picture}}" ></td>
        <td>{{$user->dvr}}</td>
        <td>{{$user->channel}}</td>
        <td>{{$user->note}}</td>
        <td>{{$user->Status}}</td>

    </tr>
  
@endforeach  



</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
