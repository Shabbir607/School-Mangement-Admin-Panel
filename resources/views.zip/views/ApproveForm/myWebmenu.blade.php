@extends('ApproveForm.app')
@section('title')
    myWebmenu
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>

<div class="container mt-5">
    <form action="{{route('savemyWeb_menu')}}" method="post"
    enctype="multipart/form-data">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
             

            <input type="text" name="category_thai" class="custom-category_thai" id="category_thai">
            <label class="custom-name_th" for="subject_thai">Category Name (Th</label>
            
                        <input type="text" name="category_english" class="custom-category_english" id="category_english">
                        <label class="custom-name_en" for="subject_english">    Category Name En</label>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
                        Submit
                    </button>
                </form>
            </div>
            <table id="myWebmenu">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Menu(English)</th>
                    <th>Menu (Thai)</th>
        
    </tr>
    </thead>
    <tbody>
@foreach ($myWebMenu as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->menu_thai}}</td>
        <td>{{$user->menu_english}}</td>
        
        <td></td>
    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

