@extends('ApproveForm.app')
@section('title')
    SummaryReport
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<table id="SummaryReport">
    <thead>
    <tr>
        <th>ID</th>
        <th>Code</th>
        <th>Product Name</th>
        <th>Price</th>
        <th>Import</th>
        <th>Sale</th>
        <th>CN</th>
        <th>Broken</th>
        <th>Internal</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
@foreach ($SummaryReport as $user)
  
    <tr>
        <td>{{$user->code}}</td>
        <td>{{$user->product_name}}</td>
        <td>{{$user->price}}</td>
        <td>{{$user->bf}}</td>
        <td>{{$user->import}}</td>
        <td>{{$user->sale}}</td>
        <td>{{$user->cn}}</td>
        <td>{{$user->broken}}</td>
        <td>{{$user->internal}}</td>
        <td>{{$user->total}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
