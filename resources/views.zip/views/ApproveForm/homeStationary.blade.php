@extends('ApproveForm.app')
@section('title')
    homeStationary
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{

        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>


<div class="container mt-5">
    <form action="{{route('savehome_Stationary')}}" method="post" enctype="multipart/form-data">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            <input type="hidden" value="{{$user_id}}" name="user" class="custom-quser" id="user">
            <input type="hidden" value="{{$name}}" name="teacher" class="custom-teacher" id="teacher">
            <label class="custom-date" for="name_th">Bill</label>
            <input type="text" name="bill" class="custom-name_th" id="bill">
              <label class="custom-date" for="name_th">Date</label>         
            <input type="date" name="date" class="custom-name_th" id="date">
            <label class="custom-date" for="name_th">Product</label>
             <select name="code" id="code">
              @foreach ($products as $product)
               <option value="{{$product->code}}">{{$product->product}}</option>
                @endforeach
            </select>
            <label class="custom-date" for="name_th">Brand Name</label>
            <select name="company" id="code">
              @foreach ($brands as $brand)
               <option value="{{$brand->id}}">{{$brand->english}}</option>
                @endforeach
            </select>
            
              <label class="custom-qty" for="qty">Qty</label>  
             <input type="text" name="qty" class="custom-qty" id="qty">
            <label class="custom-discription" for="discription">Discription</label>
            <input type="text" name="description" class="custom-discription" id="discription">
            

        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>


<table id="homePurchase">
  <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Discription</th>
        <th>Status</th>
    </tr>
</thead>
    <tbody>
@foreach ($homeStationary as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->description}}</td>
        <td>{{$user->status}}</td>
    </tr>
  
@endforeach  
</tbody>
   </table>

</section>

   
<!-- /.content -->
@endsection
