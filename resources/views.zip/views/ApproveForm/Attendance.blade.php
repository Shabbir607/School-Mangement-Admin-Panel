@extends('ApproveForm.app')
@section('title')
    Attendance
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>

<table id="Attendance">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Time In</th>
        <th>Time Out</th>
       

    </tr>
    </thead>
    <tbody>
@foreach ($attendance as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->name}}</td>
        <td>{{$user->timeIn}}</td>
        <td>{{$user->timeOut}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

