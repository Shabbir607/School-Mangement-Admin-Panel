@extends('ApproveForm.app')
@section('title')
    proCategory
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }
.container {
            max-width: 500px;
        }
        dl, ol, ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
</style>

<div class="container mt-5">
    <form action="{{route('saveprocategory')}}" method="post">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            
            <input type="text" name="name_thi" class="custom-name_th" id="name_thi">
            <label class="custom-name_thi" for="name_thi">Brand Name Th</label>
            <input type="text" name="name_engl" class="custom-name_engl" id="name_en">
            <label class="custom-name_engl" for="EngName">Brand Name En</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>

<table id="procategories">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name Thi</th>
        <th>Name Eng</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
@foreach ($procategories as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->name_thi}}</td>
        <td>{{$user->name_engl}}</td>
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

