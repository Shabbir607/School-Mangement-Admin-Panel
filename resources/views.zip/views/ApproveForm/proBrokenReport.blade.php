@extends('ApproveForm.app')
@section('title')
    proBrokenReport
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<table id="proBrokenReport">
    <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Bill</th>
        <th>Total</th>
        <th>By</th>
        <th>Status</th>
    </tr>
    </thead>
    
    <tbody>
@foreach ($proBrokenReport as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->bill}}</td>
        <td>{{$user->total}}</td>
        <td>{{$user->user_name}}</td>
        <td>{{$user->status}}</td>
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
