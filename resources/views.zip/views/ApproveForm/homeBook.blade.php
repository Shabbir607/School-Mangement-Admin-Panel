@extends('ApproveForm.app')
@section('title')
    homeBook
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<div class="container mt-5">
    <form action="{{route('savehome_booking')}}" method="post" enctype="multipart/form-data">
      
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
          <label class="custom-file-label" for="chooseFile">Select file</label>
          <input type="file" name="file" class="custom-file-input" id="chooseFile">
        </div>
            <label class="custom-room" for="room">Room Name</label>
             <select name="room" id="category">
                  <option >Auditorium</option>
                  <option >Assembly</option>
                  <option >Meeting</option>
                  
            </select>
            <label class="custom-name_th" for="name">Active Name</label>
            <input type="text" name="active" class="custom-name" id="name">
            

            <label class="custom-fan" for="fan">Fans</label>
             <select name="fan" id="fan">
                  <option >Yes</option>
                  <option >No</option>
            </select>
            <label class="custom-fan" for="chair">Chairs</label>
             <select name="chair" id="chair">
                  <option >Yes</option>
                  <option >No</option>
            </select>
            <label class="custom-light" for="light">Lights</label>
             <select name="light" id="light">
                  <option >Yes</option>
                  <option >No</option>
            </select>
            <label class="custom-air" for="air">Air Condition</label>
             <select name="air" id="air">
                  <option >Yes</option>
                  <option >No</option>
            </select>
            <label class="custom-date" for="channel">Date</label>
            <input type="date" name="date" class="date" id="date">
             <label class="custom-time" for="time">Time</label>
             <input type="time" name="time" class="time" id="time">
             <label class="custom-note" for="note">Note</label>
             <input type="text" name="note" class="note" id="note">
             <label class="custom-note" for="Other">Other Write</label>
             <input type="text" name="other" class="Other" id="note">
             


        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>

<div>
<table id="homeBook">
    <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Location</th>
        <th>Active </th>

    </tr>
    </thead>
    <tbody>
</div>
@foreach ($homeBook as $user)
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->room}}</td>
        <td>{{$user->active}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
