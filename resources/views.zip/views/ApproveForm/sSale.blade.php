@extends('ApproveForm.app')
@section('title')
    sSales
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<table id="sSale">
    <thead>
    <tr>
        <th>ID</th>
        <th>Bill</th>
        <th>Teacher</th>
        <th>Date</th>
        <th>Description</th>
        <th>Status</th>
    </tr>
    </thead>
    
    <tbody>
@foreach ($sSale as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->bill}}</td>
        <td>{{$user->teacher}}</td>
        <td>{{$user->date}}</td>
        <td>{{$user->description}}</td>
        <td>{{$user->status}}</td>
    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
