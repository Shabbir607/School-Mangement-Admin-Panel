@extends('ApproveForm.app')
@section('title')
    sItem
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

   
    .content-wrapper {
        background-color: #f9f9f9;
        padding: 20px;
    }

    .content {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .custom-file-label,
    .custom-category,
    .custom-code,
    .custom-product,
    .custom-price {
        display: block;
        margin-top: 10px;
        font-size: 14px;
    }

    .custom-file-input,
    .code,
    .custom-product,
    .custom-price {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }

    .custom-file-label {
        overflow: hidden;
    }
 /* Style for the content wrapper with !important */
 .content-wrapper {
  padding: 20px !important;

}

    /* Style for the table with !important */
#sitem{
    margin-top: 20px;
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
}

/* Style for table headers with !important */
#sitem th {
  background-color: #007bff !important;
  color: #fff !important;
  padding: 10px !important;
  text-align: left !important;
}

/* Style for table data cells with !important */
#sitem td {
  padding: 10px !important;
  border-bottom: 1px solid #ddd !important;
}

/* Style for actions column with !important */
#sitem .actions {
  display: flex !important;
  justify-content: space-between !important;
}

/* Style for action buttons with !important */
#sitem.actions button {
  background-color: #007bff !important;
  border: none !important;
  color: #fff !important;
  padding: 5px 10px !important;
  cursor: pointer !important;
}

#sitem .actions button:hover {
  background-color: #0056b3 !important;
}

/* Style for approve cells with !important */
#sitem.approve {
  font-weight: bold !important;
}

/* Style for alternate rows with !important */
#sitem tbody tr:nth-child(even) {
  background-color: #f9f9f9 !important;
}

#sitem_wrapper {
    padding-top: 20px;
}

.content-wrapper>.content {
    padding: 20px;
}

select {
    word-wrap: normal;
    width: 100%;
    margin-top: 20px;
}

</style>


<div class="container mt-5">
    <form action="{{route('saveitem')}}" method="post" enctype="multipart/form-data">
      <h3 class="text-center mb-5">Upload File in Laravel</h3>
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            <input type="file" name="file" class="custom-file-input" id="chooseFile">
            <label class="custom-file-label" for="chooseFile">Select file</label>

            <select name="category" id="category">
              @foreach ($scategory as $category)
                  <option value="{{$category->id}}">{{$category->english}}</option>

                @endforeach
            </select>

            <label class="custom-category" for="code">Category</label>

             <select name="brand" id="brand">
              @foreach ($sbrand as $brand)
                  <option value="{{$brand->id}}">{{$brand->english}}</option>
                  
                @endforeach
            </select>

            <label class="custom-category" for="code">Brand</label>
            
             <input type="text" name="code" class="code" id="code">
            <label class="custom-code" for="code">Code</label>

            <input type="text" name="product" class="custom-product" id="product">

            <label class="custom-product" for="product">Product Name</label>
            
            <input type="text" name="price" class="custom-product" id="price">
            <label class="custom-price" for="price">Price</label>
        </div>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>
<table id="sitem">
    <thead>
    <tr>
        <th>ID</th>
        <th>Category</th>
        <th>Code</th>
        <th>Brand ID</th>
        <th>Product Name</th>
        <th>Price</th>
        <th>Picture</th>
    </tr>
    </thead>
    <tbody>
@foreach ($sItem as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->category}}</td>
        <td>{{$user->code}}</td>
        <td>{{$user->brand_id}}</td>
        <td>{{$user->product}}</td>
        <td>{{$user->price}}</td>
        <td><img src="{{base_path().'/public/file/'.$user->picture}}" ></td>
    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
