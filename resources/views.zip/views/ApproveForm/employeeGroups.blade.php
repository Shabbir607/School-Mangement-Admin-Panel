@extends('ApproveForm.app')
@section('title')
    EmployeeGroups
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }
    .container {
            max-width: 500px;
        }
        dl, ol, ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        
         /* Style for the content wrapper with !important */
.content-wrapper {
  padding: 20px !important;
}



</style>
@section('content')
<div class="container mt-5">
    <form action="{{route('savegroup')}}" method="post" enctype="multipart/form-data">
      
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            
           
            <input type="text" name="language_thi" class="custom-name_th" id="language_thi">
            <label class="custom-language_thi" for="language_thi">Language Thi</label>
            <input type="text" name="language_engli" class="custom-language_engli" id="language_engli">
            <label class="custom-language_engli" for="language_engli">Language Engl</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>
<table id="sBrand">
    <thead>
    <tr>
        <th>ID</th>
        <th>Language Thi</th>
        <th>Language Engl</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>

@foreach ($groups as $user)
  
    <tr>
        <td>{{$user->id}}</td>
       
        <td>{{$user->language_thi}}</td>
        <td>{{$user->language_engli}}</td>
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
