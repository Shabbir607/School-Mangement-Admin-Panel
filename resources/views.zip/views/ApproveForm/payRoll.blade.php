@extends('ApproveForm.app')
@section('title')
    payRoll
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }
    .container {
            max-width: 500px;
        }
        dl, ol, ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        /* Override Bootstrap container max-width with !important */
.container {
    max-width: 100% !important;
}

/* Form styles */
.custom-file {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.custom-file input[type="text"],
.custom-file select {
    width: calc(50% - 10px) !important;
    padding: 8px !important;
    margin-bottom: 10px !important;
}

.custom-file label,
.custom-file select {
    width: calc(50% - 10px) !important;
    padding: 8px !important;
}

.custom-file label {
    margin-bottom: 0 !important;
}

.btn-primary {
    background-color: #007bff !important;
    border-color: #007bff !important;
    color: #fff !important;
    padding: 10px 20px !important;
    font-size: 16px !important;
}

.btn-primary:hover {
    background-color: #0056b3 !important;
    border-color: #0056b3 !important;
}

/* Table styles */
#parRoll {
    border-collapse: collapse !important;
    width: 100% !important;
    border: 1px solid black !important;
}

#parRoll th,
#parRoll td {
    border: 1px solid black !important;
    text-align: center !important;
    padding: 8px !important;
}

#parRoll th {
    background-color: #f2f2f2 !important;
}

#parRoll tr:nth-child(odd) {
    background-color: #f2f2f2 !important;
}


</style>
@section('content')
<div class="container mt-5">
    <form action="{{route('savepayroll')}}" method="post" enctype="multipart/form-data">
      
        @csrf
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <strong>{{ $message }}</strong>
        </div>
      @endif
      @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
        <div class="custom-file">
            
           
            <input type="text" name="language_thi" class="custom-name_th" id="language_thi">
            <label class="custom-language_thi" for="language_thi">Language Thi</label>
            <input type="text" name="language_engli" class="custom-language_engli" id="language_engli">
            <label class="custom-language_engli" for="language_engli">Language Engl</label>

            <select name="type" id="type">
               <option>Income</option>
               <option>Deduct</option>
            </select>

            <label class="custom-type" for="type">Type</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
            Submit
        </button>
    </form>
</div>
<table id="parRoll">
    <thead>
    <tr>
        <th>ID</th>
        <th>Language Thi</th>
        <th>Language Engl</th>
        <th>Type</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>

@foreach ($payRoll as $user)
  
    <tr>
        <td>{{$user->id}}</td>   
        <td>{{$user->language_thi}}</td>
        <td>{{$user->language_engli}}</td>
        <td>{{$user->type}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
