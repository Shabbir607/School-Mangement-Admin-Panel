@extends('ApproveForm.app')
@section('title')
    sRefund
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<table id="sRefund">
    <thead>
    <tr>
        <th>ID</th>
        <th>Picture</th>
        <th>Language</th>
        <th>English</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
@foreach ($sRefund as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td><img src="{{base_path().'/public/file/'.$user->picture}}" ></td>
        <td>{{$user->language}}</td>
        <td>{{$user->english}}</td>
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
