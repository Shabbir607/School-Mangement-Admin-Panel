@extends('ApproveForm.app')
@section('title')
    proSales
@endsection
@section('content')


<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>
@section('content')
<table id="proSale">
    <thead>
    <tr>
        <th>ID</th>
        <th>Code</th>
        <th>Product Name</th>
        <th>Qty</th>
        <th>Total</th>
        <th>Status</th>
    </tr>
    </thead>
    
    <tbody>
@foreach ($proSale as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->product_code}}</td>
        <td>{{$user->product_name}}</td>
        <td>{{$user->qty}}</td>
        <td>{{$user->total}}</td>
        <td>{{$user->status}}</td>
        
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection
