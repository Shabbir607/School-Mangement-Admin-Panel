@extends('ApproveForm.app')
@section('title')
    VisaDocument
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>

<table id="VisaDocument">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Visa</th>
        <th>Visa Expire</th>
        
        
       

    </tr>
    </thead>
    <tbody>
@foreach ($visaDocument as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->name}}</td>
        <td>{{$user->visa_number}}</td>
        <td>{{$user->expire}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

