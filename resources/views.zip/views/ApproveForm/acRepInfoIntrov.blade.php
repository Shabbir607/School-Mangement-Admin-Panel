@extends('ApproveForm.app')
@section('title')
    acRepInfoIntrov
@endsection
@section('content')

<!-- Main content -->
<section class="content">
<style>

    table{
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }
    th , td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }
    th{
        background-color: #f2f2f2;
    }
    tr:nth-child(odd){
        background-color: #f2f2f2;
    }

</style>

<table id="acRepInfoIntrov">
    <thead>
    <tr>
        <th>ID</th>
        <th>Student</th>
        <th>Teacher</th>
        <th>Subject</th>
        <th>Action</th>

    </tr>
    </thead>
    <tbody>
@foreach ($acRepInfoIntrov as $user)
  
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->subject}}</td>
        <td>{{$user->student}}</td>
        <td>{{$user->teacher}}</td>
        <td></td>

    </tr>
  
@endforeach  
</tbody>
   </table>
</section>

   
<!-- /.content -->
@endsection

